public interface LandVehicle extends Vehicle {
    void drive();
}

