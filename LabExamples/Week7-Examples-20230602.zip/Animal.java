
public interface Animal {

	void speak();
	
}
