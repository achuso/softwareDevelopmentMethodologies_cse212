
public class StudentTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student myStudent=new Student();
		myStudent.displayStudentInformation();
		Student myStudent1=new Student();
		myStudent1.displayStudentInformation();
		Student myStudent2=new Student();
		myStudent2.displayStudentInformation();

	}

}
