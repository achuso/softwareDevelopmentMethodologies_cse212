
public class StudentContainingCourseTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentContainingCourse s1=new StudentContainingCourse();
		s1.displayInformation();
	}

}
