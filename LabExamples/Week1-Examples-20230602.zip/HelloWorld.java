import java.util.Scanner;

public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Hello World!");
		
		
		/*
		String a = "CSE212" + "Spring";
		System.out.println(a);
		
		String b = 200 + 12 + "CSE" + 200 + 12;
		System.out.println(b);
		
		String s1 = "hello";
		String s2 = "hello";
		String s3 = new String("hello");
		System.out.println(s1 == s2);
		System.out.println(s1 == s3);
		System.out.println(s1.equals(s2));
		System.out.println(s1.equals(s3));
		
		
		Scanner myScanner = new Scanner(System.in);
		System.out.printf("%s", "Enter a word:");
		String word = myScanner.nextLine();
		System.out.println(word);
		
		
		System.out.printf("%s", "Enter a course name:");
		boolean bool = myScanner.hasNext();
		System.out.println(bool);
		
		*/

	}

}
