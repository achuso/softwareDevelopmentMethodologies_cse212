package myDowncasting;

class Animal {

	public void eat()
	{

		System.out.println("Animal Eating");

	}

}