import java.awt.GridLayout;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class EmptyScreen extends JFrame  {

	private JLabel[] myLabels;
	
	Icon actor=new ImageIcon("actor.jpg");
	Icon iconEmpty=new ImageIcon("empty.jpg");
	
	private GridLayout myGridLayout;
	private int row=8;
	private int column=6;
	
	public EmptyScreen()
	{
		super("myGridLayout");
		//same as frame = new JFrame("myGridLayout");

		
		myGridLayout=new GridLayout(row,column,5,5);
		setLayout(myGridLayout);
		myLabels=new JLabel[row*column];
		
		int i=0;
		myLabels[i]=new JLabel(actor);
		add(myLabels[i]);
		
		
		for(i=1;i<row*column;i++)
		{
			
			
			myLabels[i]=new JLabel(actor);
		
			add(myLabels[i]);	
			
		}		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmptyScreen myEmptyScreen=new EmptyScreen();
		myEmptyScreen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myEmptyScreen.setSize(300,200);
		myEmptyScreen.setVisible(true);

	}
	
	
}
