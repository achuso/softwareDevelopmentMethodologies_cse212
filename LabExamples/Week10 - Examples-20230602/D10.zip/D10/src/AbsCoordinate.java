import javax.swing.*;

public class AbsCoordinate{
	
  private JFrame frame;
  private JPanel panel;
  private Icon actor;
  private JLabel label1;
  
  public void createGUI(){
      frame = new JFrame("GUI Demo");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


      panel = new JPanel();
      panel.setLayout(null);

      actor = new ImageIcon("actor.jpg");

      label1 = new JLabel(actor);
      // Absolute Positioning
      label1.setBounds(150, 20, 150, 100);

      panel.add(label1);
      frame.add(panel);
      
      frame.setSize(400,400);
      
      frame.setVisible(true);
 
  }
  
  public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbsCoordinate myAbsCoordinate=new AbsCoordinate();
		myAbsCoordinate.createGUI();

  }
  
}