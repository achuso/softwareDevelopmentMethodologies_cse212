import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class FlowLayoutPane extends JPanel {
  
	public FlowLayoutPane() {
	    // Use a FlowLayout layout manager. Left justify rows.
	    // Leave 10 pixels of horizontal and vertical space between components.
	    this.setLayout(new FlowLayout(FlowLayout.RIGHT, 10, 10));
	
	    // Add some buttons to demonstrate the layout.
	    String spaces = ""; // Used to make the buttons different
	    for (int i = 1; i <= 5; i++) {
		      this.add(new JButton("Button #" + i + spaces));
		      spaces += " ";
	    }
	
	    // Give ourselves a default size
	    this.setPreferredSize(new Dimension(500, 200));
  }
  
  public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		JFrame frame = new JFrame();
		    
		frame.add(new FlowLayoutPane());	
		   
		// Finally, set the size of the main window, and pop it up.
		frame.setSize(600, 400);
		frame.setVisible(true);
		  

	}
  
}
