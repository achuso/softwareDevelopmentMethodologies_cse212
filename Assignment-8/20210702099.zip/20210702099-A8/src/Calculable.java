/***************************
 * NAME: Onat Ribar
 * STUDENT NR: 20210702099
 * CSE 212 Assignment-8
 ***************************/

public interface Calculable {
	
	double getCost();
	
}
